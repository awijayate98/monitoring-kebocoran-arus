<?php
	$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "home_electric";
	$konek = mysqli_connect("$servername", "$username", "$password","$dbname");
?>