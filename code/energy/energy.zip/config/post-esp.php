<?php
include "login.php";
$api_key_value = "tPmAT5Ab3j7F9";
$api_key= $value1 = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $api_key = test_input($_POST["api_key"]);
    if($api_key == $api_key_value) {
        $value1 = test_input($_POST["value1"]);
        echo value1;
        $simpan = mysqli_query($konek, "INSERT INTO energy_status(status_alat)VALUES('$value1')");
        if($simpan)
        {
            echo tersimpan;
        }
    }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}